pref("extensions.pixImgUploader.boolpref", false);
pref("extensions.pixImgUploader.intpref", 0);
pref("extensions.pixImgUploader.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.pixImgUploader@pixnet.tw.description", "chrome://pixImgUploader/locale/overlay.properties");
